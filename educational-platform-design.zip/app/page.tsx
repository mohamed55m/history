import { Navigation } from "@/components/navigation";
import { HeroSection } from "@/components/hero-section";
import { PortalCard } from "@/components/portal-card";
import { StatsBar } from "@/components/stats-bar";

const portals = [
  {
    title: "الدروس والشروحات",
    description:
      "استكشف المحتوى التاريخي الشامل مع شروحات مفصلة وجداول زمنية ومصادر أولية. من الحضارات القديمة إلى التاريخ الحديث.",
    iconName: "book-open" as const,
    href: "/lessons",
    stats: {
      label: "متاح",
      value: "48 درس",
    },
    accentColor: "gold" as const,
  },
  {
    title: "بنك الأسئلة",
    description:
      "تدرب على مجموعتنا الواسعة من أسئلة الامتحانات. اختيار متعدد وإجابات قصيرة ومقالات مع نماذج إجابات مفصلة.",
    iconName: "help-circle" as const,
    href: "/questions",
    stats: {
      label: "الأسئلة",
      value: "+500",
    },
    accentColor: "blue" as const,
  },
  {
    title: "المراجعة السريعة",
    description:
      "راجع المفاهيم الأساسية بكفاءة من خلال البطاقات التعليمية والملخصات والخرائط الذهنية. مثالية للتحضير قبل الامتحانات.",
    iconName: "zap" as const,
    href: "/revision",
    stats: {
      label: "البطاقات",
      value: "320",
    },
    accentColor: "gold" as const,
  },
  {
    title: "مركز الاختبارات",
    description:
      "أدِّ اختبارات تجريبية كاملة في ظروف موقوتة. احصل على تغذية راجعة فورية وتحليلات أداء مفصلة لتتبع تقدمك.",
    iconName: "graduation-cap" as const,
    href: "/exams",
    stats: {
      label: "اختبارات تجريبية",
      value: "12",
    },
    accentColor: "blue" as const,
  },
];

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <HeroSection />
        
        {/* نظرة عامة على الإحصائيات */}
        <div className="mb-12">
          <StatsBar />
        </div>

        {/* قسم البوابات */}
        <section aria-labelledby="portals-heading" className="mb-12">
          <div className="mb-8 text-center">
            <h2
              id="portals-heading"
              className="mb-2 font-serif text-2xl font-semibold tracking-tight text-foreground md:text-3xl"
            >
              بوابات التعلم
            </h2>
            <p className="mx-auto max-w-2xl text-pretty text-muted-foreground">
              اختر مسار التعلم الخاص بك وابدأ استكشاف التاريخ اليوم
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {portals.map((portal) => (
              <PortalCard
                key={portal.title}
                title={portal.title}
                description={portal.description}
                iconName={portal.iconName}
                href={portal.href}
                stats={portal.stats}
                accentColor={portal.accentColor}
              />
            ))}
          </div>
        </section>

        {/* قسم النشاط الأخير */}
        <section aria-labelledby="activity-heading" className="mb-12">
          <div className="mb-6">
            <h2
              id="activity-heading"
              className="font-serif text-xl font-semibold tracking-tight text-foreground"
            >
              أكمل من حيث توقفت
            </h2>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <RecentActivityCard
              title="الحرب العالمية الثانية: المسرح الباسيفيكي"
              type="درس"
              progress={75}
              timeAgo="منذ ساعتين"
            />
            <RecentActivityCard
              title="اختبار تدريبي: الثورة الفرنسية"
              type="اختبار"
              progress={60}
              timeAgo="أمس"
            />
            <RecentActivityCard
              title="بطاقات الثورة الصناعية"
              type="مراجعة"
              progress={40}
              timeAgo="منذ 3 أيام"
            />
          </div>
        </section>
      </main>

      {/* التذييل */}
      <footer className="border-t border-border/50 bg-card/50">
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <p className="text-sm text-muted-foreground">
              &copy; {new Date().getFullYear()} مركز التاريخ. جميع الحقوق محفوظة.
            </p>
            <nav aria-label="تنقل التذييل">
              <ul className="flex gap-6">
                <li>
                  <a
                    href="#"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    مركز المساعدة
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    اتصل بنا
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    الخصوصية
                  </a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </footer>
    </div>
  );
}

function RecentActivityCard({
  title,
  type,
  progress,
  timeAgo,
}: {
  title: string;
  type: string;
  progress: number;
  timeAgo: string;
}) {
  return (
    <article className="group flex flex-col rounded-xl border border-border/50 bg-card p-4 shadow-sm transition-all hover:border-primary/20 hover:shadow-md">
      <div className="mb-3 flex items-center justify-between">
        <span className="inline-flex rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
          {type}
        </span>
        <span className="text-xs text-muted-foreground">{timeAgo}</span>
      </div>
      <h3 className="mb-3 font-medium text-foreground group-hover:text-primary line-clamp-2">
        {title}
      </h3>
      <div className="mt-auto">
        <div className="mb-1.5 flex items-center justify-between text-xs">
          <span className="text-muted-foreground">التقدم</span>
          <span className="font-medium text-foreground">{progress}%</span>
        </div>
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full bg-gradient-to-l from-primary to-secondary transition-all duration-500"
            style={{ width: `${progress}%` }}
            role="progressbar"
            aria-valuenow={progress}
            aria-valuemin={0}
            aria-valuemax={100}
          />
        </div>
      </div>
    </article>
  );
}
