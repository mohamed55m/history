import type { Metadata } from 'next'
import { Noto_Sans_Arabic, Noto_Naskh_Arabic } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const notoSansArabic = Noto_Sans_Arabic({ 
  subsets: ["arabic"],
  variable: '--font-sans',
  display: 'swap',
});

const notoNaskhArabic = Noto_Naskh_Arabic({ 
  subsets: ["arabic"],
  variable: '--font-serif',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'مركز التاريخ | بوابتك إلى الماضي',
  description: 'منصة تعليمية تفاعلية لطلاب التاريخ. استمتع بالدروس الشاملة وبنك الأسئلة ومواد المراجعة وأدوات التحضير للاختبارات.',
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ar" dir="rtl" className={`${notoSansArabic.variable} ${notoNaskhArabic.variable} bg-background`}>
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
