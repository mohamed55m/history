import { Navigation } from "@/components/navigation";
import { UnitCard } from "@/components/unit-card";
import { ArrowRight } from "lucide-react";
import Link from "next/link";

const units = [
  {
    unitNumber: 3,
    title: "مصر والدول المستقلة",
    iconName: "landmark" as const,
    href: "/lessons/unit-3",
    accentColor: "gold" as const,
    lessons: [
      {
        id: "3-1",
        title: "مصر من الفتح الإسلامي حتى قيام الدول المستقلة",
        href: "/lessons/unit-3/lesson-1",
      },
      {
        id: "3-2",
        title: "مصر في عصري الطولونيين والإخشيديين",
      },
      {
        id: "3-3",
        title: "مصر في عصر الفاطميين",
      },
      {
        id: "3-4",
        title: "مصر في عصري الأيوبيين والمماليك",
      },
    ],
  },
  {
    unitNumber: 4,
    title: "الحضارة الإسلامية وإسهاماتها",
    iconName: "building" as const,
    href: "/lessons/unit-4",
    accentColor: "blue" as const,
    lessons: [
      {
        id: "4-intro",
        title: "أسس قيام الحضارة الإسلامية وخصائصها",
        isIntro: true,
      },
      {
        id: "4-1",
        title: "النظام السياسي والإداري",
      },
      {
        id: "4-2",
        title: "النظام المالي",
      },
      {
        id: "4-3",
        title: "الحياة الاقتصادية والاجتماعية",
      },
      {
        id: "4-4",
        title: "الحياة العلمية وفنون العمارة",
      },
    ],
  },
];

export default function LessonsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pb-20 pt-24">
        {/* Header */}
        <div className="container mx-auto px-4">
          {/* Breadcrumb */}
          <nav className="mb-6 flex items-center gap-2 text-sm text-muted-foreground">
            <Link
              href="/"
              className="transition-colors hover:text-primary"
            >
              الرئيسية
            </Link>
            <ArrowRight className="h-4 w-4 rotate-180" />
            <span className="text-foreground">الدروس والشروحات</span>
          </nav>

          {/* Page Title */}
          <div className="mb-12 max-w-2xl">
            <h1 className="font-serif text-4xl font-bold text-foreground md:text-5xl">
              الدروس والشروحات
            </h1>
            <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
              استكشف وحدات التاريخ الإسلامي مع شروحات تفصيلية وموارد تعليمية شاملة.
              اختر الوحدة التي تريد دراستها وابدأ رحلتك في التعلم.
            </p>
          </div>

          {/* Stats */}
          <div className="mb-12 flex flex-wrap gap-8 rounded-xl border border-border bg-card p-6">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <span className="text-xl font-bold text-primary">2</span>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">الوحدات</p>
                <p className="font-semibold text-foreground">متاحة للدراسة</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-secondary/10">
                <span className="text-xl font-bold text-secondary">9</span>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">الدروس</p>
                <p className="font-semibold text-foreground">شرح تفصيلي</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <span className="text-xl font-bold text-primary">+50</span>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">المصادر</p>
                <p className="font-semibold text-foreground">مراجع وموارد</p>
              </div>
            </div>
          </div>

          {/* Units Grid */}
          <div className="grid gap-8 md:grid-cols-2">
            {units.map((unit) => (
              <UnitCard
                key={unit.unitNumber}
                unitNumber={unit.unitNumber}
                title={unit.title}
                lessons={unit.lessons}
                iconName={unit.iconName}
                href={unit.href}
                accentColor={unit.accentColor}
              />
            ))}
          </div>

          {/* Help Section */}
          <div className="mt-16 rounded-2xl border border-border bg-gradient-to-l from-primary/5 via-transparent to-secondary/5 p-8 text-center">
            <h2 className="font-serif text-2xl font-bold text-foreground">
              هل تحتاج مساعدة في الدراسة؟
            </h2>
            <p className="mx-auto mt-3 max-w-lg text-muted-foreground">
              يمكنك التواصل مع المعلم للحصول على شرح إضافي أو توضيح أي نقاط صعبة في الدروس.
            </p>
            <button className="mt-6 rounded-lg bg-primary px-6 py-3 font-medium text-primary-foreground transition-colors hover:bg-primary/90">
              تواصل مع المعلم
            </button>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2024 مركز التاريخ. جميع الحقوق محفوظة.</p>
        </div>
      </footer>
    </div>
  );
}
