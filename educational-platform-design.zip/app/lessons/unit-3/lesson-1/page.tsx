import Link from "next/link";
import { Navigation } from "@/components/navigation";
import { ArrowRight, Clock, BookOpen, FileText } from "lucide-react";
import { Lesson1Content } from "./lesson-1-content";

export default function Lesson1Page() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <div className="bg-gradient-to-l from-primary/10 via-primary/5 to-transparent pt-24 pb-12">
        <div className="container mx-auto px-4 md:px-6">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
            <Link href="/" className="hover:text-primary transition-colors">
              الرئيسية
            </Link>
            <ArrowRight className="w-4 h-4 rotate-180" />
            <Link href="/lessons" className="hover:text-primary transition-colors">
              الدروس
            </Link>
            <ArrowRight className="w-4 h-4 rotate-180" />
            <span className="text-foreground">الوحدة الثالثة</span>
            <ArrowRight className="w-4 h-4 rotate-180" />
            <span className="text-primary font-medium">الدرس الأول</span>
          </nav>

          {/* Title */}
          <div className="max-w-4xl">
            <div className="flex items-center gap-2 mb-4">
              <span className="px-3 py-1 bg-secondary text-secondary-foreground text-sm font-medium rounded-full">
                الوحدة الثالثة
              </span>
              <span className="px-3 py-1 bg-primary/10 text-primary text-sm font-medium rounded-full">
                الدرس الأول
              </span>
            </div>

            <h1 className="text-2xl md:text-4xl font-bold text-foreground mb-4 font-serif leading-relaxed">
              مصر من الفتح الإسلامي حتى قيام الدول المستقلة
            </h1>

            <p className="text-muted-foreground text-lg leading-relaxed mb-6">
              تعرف على كيفية دخول الإسلام إلى مصر، وأحوالها قبل الفتح، ومراحل الفتح الإسلامي،
              ونظام الحكم والإدارة في عصر الولاة.
            </p>

            {/* Meta Info */}
            <div className="flex flex-wrap items-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-secondary" />
                <span>وقت القراءة: 25 دقيقة</span>
              </div>
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-secondary" />
                <span>4 أقسام رئيسية</span>
              </div>
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-secondary" />
                <span>9 أسئلة تقييمية</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 md:px-6 py-12">
        <div className="max-w-4xl mx-auto">
          <Lesson1Content />
        </div>
      </main>

      {/* Footer Navigation */}
      <div className="border-t border-border bg-muted/30">
        <div className="container mx-auto px-4 md:px-6 py-6">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <Link
              href="/lessons"
              className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
            >
              <ArrowRight className="w-5 h-5" />
              العودة للدروس
            </Link>
            <Link
              href="/lessons/unit-3/lesson-2"
              className="flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-xl hover:bg-primary/90 transition-colors"
            >
              الدرس التالي
              <ArrowRight className="w-5 h-5 rotate-180" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
