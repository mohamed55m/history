"use client";

import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";

export function HeroSection() {
  return (
    <section className="relative overflow-hidden pb-8 pt-12 md:pb-12 md:pt-16">
      {/* عناصر الخلفية الزخرفية */}
      <div
        className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_80%_50%_at_50%_-20%,rgba(120,119,198,0.1),transparent)]"
        aria-hidden="true"
      />
      <div
        className="absolute -start-32 top-0 -z-10 h-64 w-64 rounded-full bg-secondary/10 blur-3xl"
        aria-hidden="true"
      />
      <div
        className="absolute -end-32 bottom-0 -z-10 h-64 w-64 rounded-full bg-primary/10 blur-3xl"
        aria-hidden="true"
      />

      <div className="mx-auto max-w-4xl text-center">
        {/* الشارة */}
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-secondary/30 bg-secondary/10 px-4 py-1.5">
          <Sparkles className="h-4 w-4 text-secondary" />
          <span className="text-sm font-medium text-foreground">
            مرحباً بعودتك، أيها الباحث
          </span>
        </div>

        {/* العنوان الرئيسي */}
        <h1 className="mb-4 font-serif text-4xl font-bold tracking-tight text-foreground md:text-5xl lg:text-6xl">
          <span className="text-balance">
            اكتشف{" "}
            <span className="bg-gradient-to-l from-primary to-primary/70 bg-clip-text text-transparent">
              القصص
            </span>{" "}
            التي{" "}
            <span className="bg-gradient-to-l from-secondary to-secondary/70 bg-clip-text text-transparent">
              شكّلت
            </span>{" "}
            عالمنا
          </span>
        </h1>

        {/* العنوان الفرعي */}
        <p className="mx-auto mb-8 max-w-2xl text-pretty text-lg text-muted-foreground">
          استكشف دروساً شاملة، وتدرب على أسئلة مختارة بعناية، وحضّر لامتحاناتك
          من خلال منصتنا التفاعلية لتعلم التاريخ.
        </p>

        {/* أزرار الإجراءات */}
        <div className="flex flex-wrap items-center justify-center gap-4">
          <Button
            size="lg"
            className="bg-primary px-8 text-primary-foreground hover:bg-primary/90"
          >
            استمر في التعلم
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-2 border-secondary/50 px-8 hover:bg-secondary/10"
          >
            عرض التقدم
          </Button>
        </div>
      </div>
    </section>
  );
}
