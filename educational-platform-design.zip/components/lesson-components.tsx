"use client";

import { cn } from "@/lib/utils";
import { Lightbulb, HelpCircle, CheckCircle2, ChevronDown } from "lucide-react";
import { useState } from "react";

interface SectionProps {
  title: string;
  children: React.ReactNode;
  className?: string;
}

export function Section({ title, children, className }: SectionProps) {
  return (
    <section className={cn("mb-8", className)}>
      <h2 className="text-xl md:text-2xl font-bold text-primary mb-4 pb-2 border-b-2 border-secondary/50">
        {title}
      </h2>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

interface SubSectionProps {
  title: string;
  children: React.ReactNode;
  number?: string;
}

export function SubSection({ title, children, number }: SubSectionProps) {
  return (
    <div className="mb-6">
      <h3 className="text-lg md:text-xl font-semibold text-foreground mb-3 flex items-center gap-2">
        {number && (
          <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-secondary text-secondary-foreground text-sm font-bold">
            {number}
          </span>
        )}
        {title}
      </h3>
      <div className="space-y-3 text-foreground/90 leading-relaxed">{children}</div>
    </div>
  );
}

interface InfoBoxProps {
  title?: string;
  children: React.ReactNode;
  variant?: "info" | "quote" | "note";
}

export function InfoBox({ title, children, variant = "info" }: InfoBoxProps) {
  const variants = {
    info: "bg-secondary/10 border-secondary",
    quote: "bg-primary/5 border-primary",
    note: "bg-muted border-muted-foreground/30",
  };

  return (
    <div
      className={cn(
        "p-4 rounded-lg border-r-4 my-4",
        variants[variant]
      )}
    >
      {title && (
        <div className="flex items-center gap-2 mb-2 text-primary font-semibold">
          <Lightbulb className="w-5 h-5 text-secondary" />
          {title}
        </div>
      )}
      <div className="text-foreground/85 leading-relaxed">{children}</div>
    </div>
  );
}

interface QuranVerseProps {
  verse: string;
  surah: string;
}

export function QuranVerse({ verse, surah }: QuranVerseProps) {
  return (
    <div className="bg-primary/5 p-6 rounded-xl text-center my-6 border border-primary/20">
      <p className="text-xl md:text-2xl font-serif text-primary leading-loose mb-2">
        {verse}
      </p>
      <p className="text-sm text-muted-foreground">{surah}</p>
    </div>
  );
}

interface HadithProps {
  text: string;
  source: string;
}

export function Hadith({ text, source }: HadithProps) {
  return (
    <div className="bg-secondary/10 p-4 rounded-lg my-4 border-r-4 border-secondary">
      <p className="text-foreground/90 leading-relaxed mb-2">«{text}»</p>
      <p className="text-sm text-muted-foreground">{source}</p>
    </div>
  );
}

interface QuestionCardProps {
  question: string;
  options?: { label: string; text: string }[];
  type?: "mcq" | "essay";
  answer?: string;
  explanation?: string;
}

export function QuestionCard({
  question,
  options,
  type = "mcq",
  answer,
  explanation,
}: QuestionCardProps) {
  const [showAnswer, setShowAnswer] = useState(false);

  return (
    <div className="bg-card border border-border rounded-xl p-5 my-4 shadow-sm">
      <div className="flex items-start gap-3 mb-4">
        <div className="p-2 rounded-full bg-primary/10">
          <HelpCircle className="w-5 h-5 text-primary" />
        </div>
        <p className="font-medium text-foreground flex-1">{question}</p>
      </div>

      {options && (
        <div className="space-y-2 mb-4 mr-10">
          {options.map((option) => (
            <div
              key={option.label}
              className={cn(
                "p-3 rounded-lg border transition-colors",
                showAnswer && option.label === answer
                  ? "bg-green-50 border-green-300 text-green-800"
                  : "bg-muted/50 border-border"
              )}
            >
              <span className="font-semibold ml-2">{option.label}</span>
              {option.text}
            </div>
          ))}
        </div>
      )}

      <button
        onClick={() => setShowAnswer(!showAnswer)}
        className="flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors"
      >
        <ChevronDown
          className={cn(
            "w-4 h-4 transition-transform",
            showAnswer && "rotate-180"
          )}
        />
        {showAnswer ? "إخفاء الإجابة" : "عرض الإجابة"}
      </button>

      {showAnswer && (answer || explanation) && (
        <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
          <div className="flex items-center gap-2 text-green-700 font-semibold mb-2">
            <CheckCircle2 className="w-5 h-5" />
            الإجابة الصحيحة
          </div>
          {answer && type === "mcq" && (
            <p className="text-green-800 font-medium mb-2">({answer})</p>
          )}
          {explanation && (
            <p className="text-green-700 text-sm leading-relaxed">
              {explanation}
            </p>
          )}
        </div>
      )}
    </div>
  );
}

interface TableProps {
  headers: string[];
  rows: string[][];
}

export function DataTable({ headers, rows }: TableProps) {
  return (
    <div className="overflow-x-auto my-6">
      <table className="w-full border-collapse">
        <thead>
          <tr>
            {headers.map((header, i) => (
              <th
                key={i}
                className="bg-primary text-primary-foreground p-3 text-right font-semibold border border-primary/20"
              >
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i} className={i % 2 === 0 ? "bg-muted/30" : "bg-card"}>
              {row.map((cell, j) => (
                <td
                  key={j}
                  className="p-3 border border-border text-foreground/90 leading-relaxed"
                >
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

interface BulletListProps {
  items: (string | { main: string; sub?: string[] })[];
}

export function BulletList({ items }: BulletListProps) {
  return (
    <ul className="space-y-2 mr-4">
      {items.map((item, i) => (
        <li key={i} className="flex items-start gap-2">
          <span className="w-2 h-2 rounded-full bg-secondary mt-2.5 shrink-0" />
          <div>
            {typeof item === "string" ? (
              <span className="text-foreground/90 leading-relaxed">{item}</span>
            ) : (
              <>
                <span className="text-foreground/90 leading-relaxed">
                  {item.main}
                </span>
                {item.sub && (
                  <ul className="mt-2 space-y-1 mr-4">
                    {item.sub.map((subItem, j) => (
                      <li key={j} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-primary/50 mt-2.5 shrink-0" />
                        <span className="text-foreground/80 text-sm leading-relaxed">
                          {subItem}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </>
            )}
          </div>
        </li>
      ))}
    </ul>
  );
}

interface FootnoteProps {
  children: React.ReactNode;
}

export function Footnote({ children }: FootnoteProps) {
  return (
    <p className="text-sm text-muted-foreground bg-muted/50 p-3 rounded-lg mt-4 leading-relaxed">
      {children}
    </p>
  );
}
