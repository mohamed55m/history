"use client";

import Link from "next/link";
import { cn } from "@/lib/utils";
import { BookOpen, ChevronLeft, Landmark, Building2 } from "lucide-react";

const iconMap = {
  landmark: Landmark,
  building: Building2,
} as const;

type IconName = keyof typeof iconMap;

interface Lesson {
  id: string;
  title: string;
  isIntro?: boolean;
  href?: string;
}

interface UnitCardProps {
  unitNumber: number;
  title: string;
  lessons: Lesson[];
  iconName: IconName;
  href: string;
  accentColor?: "gold" | "blue";
}

export function UnitCard({
  unitNumber,
  title,
  lessons,
  iconName,
  href,
  accentColor = "gold",
}: UnitCardProps) {
  const Icon = iconMap[iconName];

  return (
    <Link
      href={href}
      className={cn(
        "group relative block overflow-hidden rounded-2xl border border-border bg-card p-6 transition-all duration-300",
        "hover:shadow-xl hover:shadow-primary/5 hover:-translate-y-1",
        "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
      )}
    >
      {/* Accent line */}
      <div
        className={cn(
          "absolute top-0 right-0 h-1 w-full",
          accentColor === "gold"
            ? "bg-gradient-to-l from-secondary via-secondary/80 to-secondary/60"
            : "bg-gradient-to-l from-primary via-primary/80 to-primary/60"
        )}
      />

      {/* Unit number badge */}
      <div
        className={cn(
          "absolute top-4 left-4 flex h-10 w-10 items-center justify-center rounded-full text-sm font-bold",
          accentColor === "gold"
            ? "bg-secondary/20 text-secondary"
            : "bg-primary/20 text-primary"
        )}
      >
        {unitNumber}
      </div>

      {/* Icon */}
      <div
        className={cn(
          "mb-4 flex h-16 w-16 items-center justify-center rounded-xl transition-transform duration-300 group-hover:scale-110",
          accentColor === "gold"
            ? "bg-secondary/10 text-secondary"
            : "bg-primary/10 text-primary"
        )}
      >
        <Icon className="h-8 w-8" />
      </div>

      {/* Content */}
      <div className="space-y-3">
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            الوحدة {unitNumber}
          </p>
          <h3 className="mt-1 font-serif text-xl font-bold text-foreground transition-colors group-hover:text-primary">
            {title}
          </h3>
        </div>

        {/* Lessons list */}
        <div className="space-y-2 border-t border-border pt-3">
          <p className="text-xs font-medium text-muted-foreground">
            الدروس ({lessons.length})
          </p>
          <ul className="space-y-1.5">
            {lessons.map((lesson, index) => {
              const lessonNumber = lesson.isIntro ? 0 : index + (lessons[0]?.isIntro ? 0 : 1);
              const lessonLabel = lesson.isIntro ? "تمهيد" : `الدرس ${lessonNumber}`;
              
              if (lesson.href) {
                return (
                  <li key={lesson.id}>
                    <Link
                      href={lesson.href}
                      onClick={(e) => e.stopPropagation()}
                      className="flex items-center gap-2 text-sm text-foreground/80 hover:text-primary transition-colors p-1.5 -m-1.5 rounded-lg hover:bg-primary/5"
                    >
                      <BookOpen className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                      <span className="line-clamp-1">
                        {lessonLabel}: {lesson.title}
                      </span>
                    </Link>
                  </li>
                );
              }
              
              return (
                <li
                  key={lesson.id}
                  className="flex items-center gap-2 text-sm text-foreground/80 p-1.5 -m-1.5"
                >
                  <BookOpen className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                  <span className="line-clamp-1">
                    {lessonLabel}: {lesson.title}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>

        {/* Action */}
        <div
          className={cn(
            "flex items-center gap-2 pt-2 text-sm font-medium transition-colors",
            accentColor === "gold"
              ? "text-secondary group-hover:text-secondary/80"
              : "text-primary group-hover:text-primary/80"
          )}
        >
          <span>استكشف الوحدة</span>
          <ChevronLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
        </div>
      </div>
    </Link>
  );
}
