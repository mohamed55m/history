"use client";

import Link from "next/link";
import { cn } from "@/lib/utils";
import { BookOpen, HelpCircle, Zap, GraduationCap } from "lucide-react";

const iconMap = {
  "book-open": BookOpen,
  "help-circle": HelpCircle,
  zap: Zap,
  "graduation-cap": GraduationCap,
} as const;

type IconName = keyof typeof iconMap;

interface PortalCardProps {
  title: string;
  description: string;
  iconName: IconName;
  href: string;
  stats?: {
    label: string;
    value: string;
  };
  accentColor?: "gold" | "blue";
}

export function PortalCard({
  title,
  description,
  iconName,
  href,
  stats,
  accentColor = "gold",
}: PortalCardProps) {
  const Icon = iconMap[iconName];
  return (
    <Link href={href} className="group block h-full">
      <article
        className={cn(
          "relative flex h-full flex-col overflow-hidden rounded-2xl border border-border/50 bg-card p-6 shadow-sm transition-all duration-300",
          "hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5",
          "focus-within:ring-2 focus-within:ring-primary focus-within:ring-offset-2"
        )}
      >
        {/* زخرفة الزاوية */}
        <div
          className={cn(
            "absolute -start-8 -top-8 h-24 w-24 rounded-full opacity-10 transition-opacity duration-300 group-hover:opacity-20",
            accentColor === "gold" ? "bg-secondary" : "bg-primary"
          )}
          aria-hidden="true"
        />

        {/* الأيقونة */}
        <div
          className={cn(
            "mb-5 flex h-14 w-14 items-center justify-center rounded-xl transition-transform duration-300 group-hover:scale-105",
            accentColor === "gold"
              ? "bg-secondary/20 text-secondary"
              : "bg-primary/10 text-primary"
          )}
        >
          <Icon className="h-7 w-7" strokeWidth={1.5} />
        </div>

        {/* المحتوى */}
        <h3 className="mb-2 font-serif text-xl font-semibold tracking-tight text-foreground">
          {title}
        </h3>
        <p className="mb-4 flex-1 text-sm leading-relaxed text-muted-foreground">
          {description}
        </p>

        {/* شارة الإحصائيات */}
        {stats && (
          <div className="mt-auto">
            <div className="inline-flex items-center gap-2 rounded-full bg-muted px-3 py-1.5">
              <span className="text-xs font-medium text-muted-foreground">
                {stats.label}
              </span>
              <span
                className={cn(
                  "text-sm font-semibold",
                  accentColor === "gold" ? "text-secondary" : "text-primary"
                )}
              >
                {stats.value}
              </span>
            </div>
          </div>
        )}

        {/* مؤشر السهم */}
        <div
          className={cn(
            "absolute bottom-6 start-6 flex h-8 w-8 items-center justify-center rounded-full transition-all duration-300",
            "opacity-0 group-hover:opacity-100",
            accentColor === "gold" ? "bg-secondary/20" : "bg-primary/10"
          )}
          aria-hidden="true"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className={cn(
              "h-4 w-4 rotate-180",
              accentColor === "gold" ? "text-secondary" : "text-primary"
            )}
          >
            <path d="M5 12h14" />
            <path d="m12 5 7 7-7 7" />
          </svg>
        </div>
      </article>
    </Link>
  );
}
