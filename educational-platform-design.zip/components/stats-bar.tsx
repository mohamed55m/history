import { BookOpen, CheckCircle2, Clock, Trophy } from "lucide-react";

const stats = [
  {
    label: "الدروس المكتملة",
    value: "24",
    total: "48",
    icon: BookOpen,
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    label: "الأسئلة المُتدرب عليها",
    value: "156",
    total: "500",
    icon: CheckCircle2,
    color: "text-secondary",
    bgColor: "bg-secondary/10",
  },
  {
    label: "ساعات الدراسة",
    value: "32",
    total: null,
    icon: Clock,
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    label: "نقاط الإنجاز",
    value: "1,240",
    total: null,
    icon: Trophy,
    color: "text-secondary",
    bgColor: "bg-secondary/10",
  },
];

export function StatsBar() {
  return (
    <section
      className="mx-auto max-w-5xl"
      aria-labelledby="progress-stats-heading"
    >
      <h2 id="progress-stats-heading" className="sr-only">
        إحصائيات تقدمك
      </h2>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {stats.map((stat) => (
          <div
            key={stat.label}
            className="flex items-center gap-3 rounded-xl border border-border/50 bg-card p-4 shadow-sm"
          >
            <div
              className={`flex h-10 w-10 items-center justify-center rounded-lg ${stat.bgColor}`}
            >
              <stat.icon className={`h-5 w-5 ${stat.color}`} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-muted-foreground truncate">{stat.label}</p>
              <p className="text-lg font-semibold text-foreground">
                {stat.value}
                {stat.total && (
                  <span className="text-sm font-normal text-muted-foreground">
                    /{stat.total}
                  </span>
                )}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
